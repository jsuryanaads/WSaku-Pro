-- WSaku Pro dedicated Supabase schema.
-- IMPORTANT: apply this only to the dedicated WSaku Pro Supabase project.
create extension if not exists pgcrypto;

create schema if not exists private;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now()
);

create table if not exists public.workspace_members (
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'user' check (role in ('admin','user')),
  created_at timestamptz not null default now(),
  primary key (workspace_id, user_id)
);

create table if not exists public.cash_accounts (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  name text not null,
  type text not null default 'cash' check (type in ('cash','bank','ewallet')),
  opening_balance numeric(18,2) not null default 0,
  is_active boolean not null default true,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now()
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  name text not null,
  kind text not null check (kind in ('income','expense')),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(workspace_id, name, kind)
);

create table if not exists public.accounts (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  name text not null,
  code text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(workspace_id, name)
);

create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  transaction_date date not null default current_date,
  type text not null check (type in ('income','expense','transfer')),
  cash_account_id uuid references public.cash_accounts(id) on delete restrict,
  category_id uuid references public.categories(id) on delete restrict,
  account_id uuid references public.accounts(id) on delete restrict,
  amount numeric(18,2) not null check (amount > 0),
  description text,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.transaction_transfers (
  transaction_id uuid primary key references public.transactions(id) on delete cascade,
  source_cash_account_id uuid not null references public.cash_accounts(id) on delete restrict,
  destination_cash_account_id uuid not null references public.cash_accounts(id) on delete restrict,
  check (source_cash_account_id <> destination_cash_account_id)
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid references public.workspaces(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  action text not null,
  table_name text,
  record_id uuid,
  created_at timestamptz not null default now()
);

create index if not exists idx_ws_members_user on public.workspace_members(user_id);
create index if not exists idx_transactions_workspace_date on public.transactions(workspace_id, transaction_date desc);
create index if not exists idx_cash_accounts_workspace on public.cash_accounts(workspace_id);
create index if not exists idx_categories_workspace on public.categories(workspace_id);
create index if not exists idx_accounts_workspace on public.accounts(workspace_id);

-- Profile bootstrap from Supabase Auth. Authorization never relies on user_metadata.
create or replace function private.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', ''))
  on conflict (id) do update set full_name = excluded.full_name, updated_at = now();
  return new;
end;
$$;

revoke all on function private.handle_new_user() from public;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure private.handle_new_user();

-- RLS helper functions live in the private schema to avoid exposing SECURITY DEFINER helpers.
create or replace function private.is_workspace_member(p_workspace_id uuid, p_user_id uuid)
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1 from public.workspace_members
    where workspace_id = p_workspace_id and user_id = p_user_id
  );
$$;

create or replace function private.is_workspace_admin(p_workspace_id uuid, p_user_id uuid)
returns boolean
language sql stable security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1 from public.workspace_members
    where workspace_id = p_workspace_id and user_id = p_user_id and role = 'admin'
  );
$$;

revoke all on function private.is_workspace_member(uuid, uuid) from public;
revoke all on function private.is_workspace_admin(uuid, uuid) from public;

-- Controlled RPC for the first workspace. It checks auth.uid() and only creates data for that user.
create or replace function public.bootstrap_workspace(p_name text default 'Keuangan Pribadi')
returns uuid
language plpgsql
security definer
set search_path = public, private, pg_temp
as $$
declare
  v_user uuid := auth.uid();
  v_workspace uuid;
  v_name text := nullif(trim(p_name), '');
begin
  if v_user is null then raise exception 'not authenticated'; end if;
  if v_name is null then v_name := 'Keuangan Pribadi'; end if;

  select workspace_id into v_workspace
  from public.workspace_members
  where user_id = v_user
  order by created_at asc
  limit 1;

  if v_workspace is not null then return v_workspace; end if;

  insert into public.workspaces(name, created_by) values (v_name, v_user) returning id into v_workspace;
  insert into public.workspace_members(workspace_id, user_id, role) values (v_workspace, v_user, 'admin');

  return v_workspace;
end;
$$;

revoke all on function public.bootstrap_workspace(text) from public;
grant execute on function public.bootstrap_workspace(text) to authenticated;

alter table public.profiles enable row level security;
alter table public.workspaces enable row level security;
alter table public.workspace_members enable row level security;
alter table public.cash_accounts enable row level security;
alter table public.categories enable row level security;
alter table public.accounts enable row level security;
alter table public.transactions enable row level security;
alter table public.transaction_transfers enable row level security;
alter table public.audit_logs enable row level security;

-- Policies are recreated so this file can be safely reapplied during development.
do $$
declare r record;
begin
  for r in select schemaname, tablename, policyname from pg_policies where schemaname='public' and tablename in ('profiles','workspaces','workspace_members','cash_accounts','categories','accounts','transactions','transaction_transfers','audit_logs') loop
    execute format('drop policy if exists %I on %I.%I', r.policyname, r.schemaname, r.tablename);
  end loop;
end $$;

create policy profiles_select_own on public.profiles for select to authenticated using (id = (select auth.uid()));
create policy profiles_insert_own on public.profiles for insert to authenticated with check (id = (select auth.uid()));
create policy profiles_update_own on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));

create policy workspaces_select_member on public.workspaces for select to authenticated using (private.is_workspace_member(id, (select auth.uid())));
create policy workspaces_update_admin on public.workspaces for update to authenticated using (private.is_workspace_admin(id, (select auth.uid()))) with check (private.is_workspace_admin(id, (select auth.uid())));

create policy members_select_member on public.workspace_members for select to authenticated using (private.is_workspace_member(workspace_id, (select auth.uid())));
create policy members_insert_admin on public.workspace_members for insert to authenticated with check (private.is_workspace_admin(workspace_id, (select auth.uid())));
create policy members_update_admin on public.workspace_members for update to authenticated using (private.is_workspace_admin(workspace_id, (select auth.uid()))) with check (private.is_workspace_admin(workspace_id, (select auth.uid())));
create policy members_delete_admin on public.workspace_members for delete to authenticated using (private.is_workspace_admin(workspace_id, (select auth.uid())));

create policy cash_accounts_member on public.cash_accounts for select to authenticated using (private.is_workspace_member(workspace_id, (select auth.uid())));
create policy cash_accounts_write on public.cash_accounts for all to authenticated using (private.is_workspace_member(workspace_id, (select auth.uid()))) with check (private.is_workspace_member(workspace_id, (select auth.uid())));
create policy categories_member on public.categories for select to authenticated using (private.is_workspace_member(workspace_id, (select auth.uid())));
create policy categories_write on public.categories for all to authenticated using (private.is_workspace_member(workspace_id, (select auth.uid()))) with check (private.is_workspace_member(workspace_id, (select auth.uid())));
create policy accounts_member on public.accounts for select to authenticated using (private.is_workspace_member(workspace_id, (select auth.uid())));
create policy accounts_write on public.accounts for all to authenticated using (private.is_workspace_member(workspace_id, (select auth.uid()))) with check (private.is_workspace_member(workspace_id, (select auth.uid())));
create policy transactions_member on public.transactions for select to authenticated using (private.is_workspace_member(workspace_id, (select auth.uid())));
create policy transactions_write on public.transactions for all to authenticated using (private.is_workspace_member(workspace_id, (select auth.uid()))) with check (private.is_workspace_member(workspace_id, (select auth.uid())));
create policy transfers_member on public.transaction_transfers for select to authenticated using (exists (select 1 from public.transactions t where t.id = transaction_id and private.is_workspace_member(t.workspace_id, (select auth.uid()))));
create policy transfers_write on public.transaction_transfers for all to authenticated using (exists (select 1 from public.transactions t where t.id = transaction_id and private.is_workspace_member(t.workspace_id, (select auth.uid())))) with check (exists (select 1 from public.transactions t where t.id = transaction_id and private.is_workspace_member(t.workspace_id, (select auth.uid()))));
create policy audit_logs_member on public.audit_logs for select to authenticated using (workspace_id is null or private.is_workspace_member(workspace_id, (select auth.uid())));

-- Public schema functions should not be callable anonymously.
