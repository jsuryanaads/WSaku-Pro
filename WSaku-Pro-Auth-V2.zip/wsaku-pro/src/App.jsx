import { useEffect, useMemo, useState } from "react";
import { supabase } from "./lib/supabase";
import {
  ArrowDownLeft,
  ArrowLeftRight,
  ArrowUpRight,
  Bell,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CircleHelp,
  CreditCard,
  FileBarChart,
  Home,
  Menu,
  Moon,
  MoreHorizontal,
  Plus,
  Search,
  Settings,
  ShieldCheck,
  Sun,
  UserRound,
  WalletCards,
  X,
} from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const chartData = [
  { day: "1", income: 900000, expense: 350000, balance: 10300000 },
  { day: "2", income: 1300000, expense: 500000, balance: 11100000 },
  { day: "3", income: 850000, expense: 780000, balance: 11200000 },
  { day: "4", income: 1750000, expense: 650000, balance: 12300000 },
  { day: "5", income: 1450000, expense: 1100000, balance: 12650000 },
  { day: "6", income: 1900000, expense: 900000, balance: 13650000 },
  { day: "7", income: 1200000, expense: 720000, balance: 14130000 },
];

const transactions = [
  { title: "Gaji Bulanan", category: "Pemasukan", date: "07 Sep 2026", amount: 5000000, type: "income", icon: ArrowDownLeft },
  { title: "Belanja Supermarket", category: "Pengeluaran", date: "06 Sep 2026", amount: 350000, type: "expense", icon: ArrowUpRight },
  { title: "Transfer ke Tabungan", category: "Transfer", date: "05 Sep 2026", amount: 1000000, type: "transfer", icon: ArrowLeftRight },
  { title: "Listrik", category: "Pengeluaran", date: "04 Sep 2026", amount: 250000, type: "expense", icon: ArrowUpRight },
  { title: "Freelance", category: "Pemasukan", date: "03 Sep 2026", amount: 750000, type: "income", icon: ArrowDownLeft },
];

const menu = [
  { label: "Dashboard", icon: Home },
  { label: "Transaksi", icon: ArrowLeftRight },
  { label: "Master Data", icon: WalletCards },
  { label: "Laporan", icon: FileBarChart },
  { label: "Pengguna", icon: UserRound },
];

const money = (value) =>
  new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0,
  }).format(value);

function Logo() {
  return (
    <div className="flex items-center gap-3">
      <div className="grid h-10 w-10 place-items-center rounded-xl bg-blue-600 text-white shadow-lg shadow-blue-600/20">
        <WalletCards size={22} strokeWidth={2.3} />
      </div>
      <div>
        <div className="text-[20px] font-extrabold leading-none tracking-tight">
          WSaku <span className="text-blue-600">Pro</span>
        </div>
        <div className="mt-1 text-[10px] font-medium text-slate-400">
          Kelola keuangan, raih masa depan
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, trend, type, icon: Icon }) {
  const styles = {
    balance: "bg-blue-50 text-blue-600",
    income: "bg-emerald-50 text-emerald-600",
    expense: "bg-red-50 text-red-600",
    transfer: "bg-indigo-50 text-indigo-600",
  };
  return (
    <div className="card min-w-0 p-4 transition hover:-translate-y-0.5 hover:shadow-lg sm:p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium text-slate-500">{title}</p>
          <p className="mt-2 truncate text-xl font-extrabold tracking-tight text-slate-900 sm:text-2xl">
            {value}
          </p>
        </div>
        <div className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${styles[type]}`}>
          <Icon size={19} />
        </div>
      </div>
      {trend && <p className="mt-3 text-[11px] font-semibold text-emerald-600">{trend}</p>}
    </div>
  );
}

function TransactionRow({ item }) {
  const Icon = item.icon;
  const colors =
    item.type === "income"
      ? "bg-emerald-50 text-emerald-600"
      : item.type === "expense"
        ? "bg-red-50 text-red-600"
        : "bg-blue-50 text-blue-600";

  const amount =
    item.type === "income"
      ? `+ ${money(item.amount)}`
      : item.type === "expense"
        ? `- ${money(item.amount)}`
        : money(item.amount);

  const amountColor =
    item.type === "income"
      ? "text-emerald-600"
      : item.type === "expense"
        ? "text-red-600"
        : "text-blue-600";

  return (
    <div className="flex items-center gap-3 border-b border-slate-100 py-3.5 last:border-0">
      <div className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${colors}`}>
        <Icon size={18} />
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-semibold text-slate-800">{item.title}</p>
        <p className="mt-0.5 text-[11px] text-slate-400">
          {item.category} · {item.date}
        </p>
      </div>
      <p className={`shrink-0 text-xs font-bold sm:text-sm ${amountColor}`}>{amount}</p>
    </div>
  );
}

function Sidebar({ collapsed, setCollapsed, mobileOpen, setMobileOpen, active, setActive }) {
  return (
    <>
      {mobileOpen && (
        <button
          aria-label="Tutup menu"
          className="fixed inset-0 z-40 bg-slate-950/30 backdrop-blur-sm lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}
      <aside
        className={[
          "fixed inset-y-0 left-0 z-50 flex w-[260px] flex-col border-r border-slate-200 bg-white px-4 py-5 transition-all duration-200",
          collapsed ? "lg:w-[82px]" : "",
          mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
        ].join(" ")}
      >
        <div className="flex items-center justify-between px-2">
          {!collapsed && <Logo />}
          {collapsed && (
            <div className="mx-auto grid h-10 w-10 place-items-center rounded-xl bg-blue-600 text-white">
              <WalletCards size={22} />
            </div>
          )}
          <button
            className="rounded-lg p-2 text-slate-400 hover:bg-slate-100 lg:hidden"
            onClick={() => setMobileOpen(false)}
          >
            <X size={20} />
          </button>
        </div>

        <div className="mt-8 space-y-1">
          {menu.map(({ label, icon: Icon }) => (
            <button
              key={label}
              onClick={() => {
                setActive(label);
                setMobileOpen(false);
              }}
              className={[
                "nav-item flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold",
                active === label
                  ? "bg-blue-50 text-blue-700"
                  : "text-slate-500 hover:bg-slate-50 hover:text-slate-900",
              ].join(" ")}
            >
              <Icon size={19} className="shrink-0" />
              {!collapsed && <span>{label}</span>}
            </button>
          ))}
        </div>

        {!collapsed && (
          <>
            <div className="mt-auto rounded-2xl bg-slate-50 p-3">
              <p className="px-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                Ruang aktif
              </p>
              <button className="mt-2 flex w-full items-center justify-between rounded-xl bg-white px-3 py-2.5 text-xs font-semibold text-slate-700 shadow-sm">
                <span className="flex items-center gap-2">
                  <ShieldCheck size={16} className="text-blue-600" />
                  Keuangan Pribadi
                </span>
                <ChevronDown size={14} />
              </button>
            </div>
            <button className="mt-3 flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold text-slate-500 hover:bg-slate-50 hover:text-slate-900">
              <Settings size={19} />
              Pengaturan
            </button>
          </>
        )}

        <div className={`mt-3 flex items-center gap-3 border-t border-slate-100 pt-4 ${collapsed ? "justify-center" : ""}`}>
          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-slate-900 text-xs font-bold text-white">
            JS
          </div>
          {!collapsed && (
            <div className="min-w-0">
              <p className="truncate text-xs font-bold text-slate-800">Jajang Suryana</p>
              <p className="truncate text-[10px] text-slate-400">Personal Workspace</p>
            </div>
          )}
        </div>
      </aside>
    </>
  );
}

function Header({ setMobileOpen, collapsed, setCollapsed, dark, setDark }) {
  return (
    <header className="sticky top-0 z-30 border-b border-slate-200/80 bg-white/85 backdrop-blur-xl">
      <div className="flex h-[72px] items-center gap-3 px-4 sm:px-6 lg:px-8">
        <button
          className="rounded-xl p-2 text-slate-500 hover:bg-slate-100 lg:hidden"
          onClick={() => setMobileOpen(true)}
        >
          <Menu size={21} />
        </button>
        <button
          className="hidden rounded-xl p-2 text-slate-500 hover:bg-slate-100 lg:block"
          onClick={() => setCollapsed(!collapsed)}
          title="Collapse sidebar"
        >
          {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
        </button>

        <div className="relative hidden max-w-[420px] flex-1 md:block">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={17} />
          <input
            placeholder="Cari transaksi, kategori, atau apa saja..."
            className="h-10 w-full rounded-xl border border-slate-200 bg-slate-50/80 pl-10 pr-4 text-xs outline-none transition focus:border-blue-300 focus:bg-white focus:ring-4 focus:ring-blue-500/5"
          />
        </div>

        <div className="ml-auto flex items-center gap-1">
          <button className="grid h-10 w-10 place-items-center rounded-xl text-slate-500 hover:bg-slate-100">
            <CircleHelp size={18} />
          </button>
          <button className="relative grid h-10 w-10 place-items-center rounded-xl text-slate-500 hover:bg-slate-100">
            <Bell size={18} />
            <span className="absolute right-2.5 top-2 h-1.5 w-1.5 rounded-full bg-red-500" />
          </button>
          <button
            onClick={() => setDark(!dark)}
            className="grid h-10 w-10 place-items-center rounded-xl text-slate-500 hover:bg-slate-100"
            title="Tema"
          >
            {dark ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <div className="ml-1 hidden items-center gap-2 border-l border-slate-200 pl-3 sm:flex">
            <div className="grid h-9 w-9 place-items-center rounded-full bg-slate-900 text-xs font-bold text-white">JS</div>
            <div className="hidden lg:block">
              <p className="text-xs font-bold text-slate-800">Jajang Suryana</p>
              <p className="text-[10px] text-slate-400">Personal Workspace</p>
            </div>
            <ChevronDown size={14} className="text-slate-400" />
          </div>
        </div>
      </div>
    </header>
  );
}

function QuickAction({ label, icon: Icon, tone, onClick }) {
  const toneClass = {
    income: "bg-blue-600 text-white shadow-blue-600/20 hover:bg-blue-700",
    expense: "bg-red-50 text-red-600 hover:bg-red-100",
    transfer: "bg-indigo-50 text-indigo-600 hover:bg-indigo-100",
    report: "bg-slate-50 text-slate-700 hover:bg-slate-100",
  }[tone];

  return (
    <button
      onClick={onClick}
      className={`flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-xs font-bold shadow-sm transition ${toneClass}`}
    >
      <Icon size={16} />
      {label}
    </button>
  );
}

function Dashboard({ setActive }) {
  const [period, setPeriod] = useState("7 Hari Terakhir");

  const tooltip = useMemo(
    () => ({
      formatter: (value) => money(value),
      labelFormatter: (label) => `Tanggal ${label}`,
    }),
    []
  );

  return (
    <main className="mx-auto w-full max-w-[1500px] px-4 py-5 sm:px-6 sm:py-7 lg:px-8">
      <div className="mb-5 flex flex-col gap-3 sm:mb-6 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-semibold text-blue-600">Dashboard</p>
          <h1 className="mt-1 text-2xl font-extrabold tracking-tight text-slate-900 sm:text-[28px]">
            Selamat datang kembali, Jajang 👋
          </h1>
          <p className="mt-1 text-xs text-slate-400 sm:text-sm">
            Kelola keuangan dengan lebih baik, capai tujuan Anda.
          </p>
        </div>
        <select
          value={period}
          onChange={(e) => setPeriod(e.target.value)}
          className="h-10 w-full rounded-xl border border-slate-200 bg-white px-3 text-xs font-semibold text-slate-600 outline-none sm:w-auto"
        >
          <option>7 Hari Terakhir</option>
          <option>Bulan Ini</option>
          <option>3 Bulan</option>
          <option>1 Tahun</option>
        </select>
      </div>

      <section className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard title="Saldo Kas" value={money(12450000)} trend="↑ 12% dari bulan lalu" type="balance" icon={WalletCards} />
        <StatCard title="Pendapatan" value={money(8250000)} trend="↑ 18% dari bulan lalu" type="income" icon={ArrowDownLeft} />
        <StatCard title="Pengeluaran" value={money(5120000)} trend="↓ 5% dari bulan lalu" type="expense" icon={ArrowUpRight} />
        <StatCard title="Transfer" value={money(1500000)} trend="3 transfer bulan ini" type="transfer" icon={ArrowLeftRight} />
      </section>

      <section className="mt-4 grid gap-4 xl:grid-cols-[minmax(0,1.65fr)_minmax(330px,.75fr)]">
        <div className="card min-w-0 p-4 sm:p-5">
          <div className="mb-2 flex items-center justify-between gap-3">
            <div>
              <h2 className="text-sm font-extrabold text-slate-900 sm:text-base">Grafik Arus Kas</h2>
              <p className="mt-0.5 text-[11px] text-slate-400">Perbandingan pemasukan dan pengeluaran</p>
            </div>
            <button className="rounded-lg p-2 text-slate-400 hover:bg-slate-50">
              <MoreHorizontal size={18} />
            </button>
          </div>
          <div className="mt-2 h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 14, right: 8, left: -18, bottom: 0 }}>
                <defs>
                  <linearGradient id="balanceFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#2563eb" stopOpacity={0.18} />
                    <stop offset="100%" stopColor="#2563eb" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid vertical={false} stroke="#eef2f7" />
                <XAxis dataKey="day" tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <YAxis
                  tick={{ fontSize: 10, fill: "#94a3b8" }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(v) => `${Math.round(v / 1000000)}M`}
                />
                <Tooltip
                  contentStyle={{ borderRadius: 12, border: "1px solid #e8edf5", boxShadow: "0 8px 30px rgba(15,23,42,.08)" }}
                  formatter={tooltip.formatter}
                  labelFormatter={tooltip.labelFormatter}
                />
                <Area type="monotone" dataKey="balance" stroke="#2563eb" strokeWidth={2.5} fill="url(#balanceFill)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card min-w-0 p-4 sm:p-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-extrabold text-slate-900 sm:text-base">Transaksi Terbaru</h2>
              <p className="mt-0.5 text-[11px] text-slate-400">Aktivitas keuangan terbaru</p>
            </div>
            <button
              onClick={() => setActive("Transaksi")}
              className="text-[11px] font-bold text-blue-600 hover:text-blue-700"
            >
              Lihat semua
            </button>
          </div>
          <div className="mt-2">
            {transactions.slice(0, 4).map((item) => <TransactionRow item={item} key={item.title} />)}
          </div>
        </div>
      </section>

      <section className="mt-4 card p-4 sm:p-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-sm font-extrabold text-slate-900">Quick Actions</h2>
            <p className="mt-0.5 text-[11px] text-slate-400">Catat transaksi tanpa langkah yang rumit.</p>
          </div>
          <div className="grid grid-cols-2 gap-2 sm:flex sm:flex-wrap">
            <QuickAction label="Pemasukan" icon={Plus} tone="income" onClick={() => setActive("Transaksi")} />
            <QuickAction label="Pengeluaran" icon={ArrowUpRight} tone="expense" onClick={() => setActive("Transaksi")} />
            <QuickAction label="Transfer" icon={ArrowLeftRight} tone="transfer" onClick={() => setActive("Transaksi")} />
            <QuickAction label="Lihat Laporan" icon={FileBarChart} tone="report" onClick={() => setActive("Laporan")} />
          </div>
        </div>
      </section>

      <section className="mt-4 grid gap-4 md:grid-cols-2">
        <div className="card p-5">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-50 text-emerald-600"><CreditCard size={19} /></div>
            <div>
              <h2 className="text-sm font-extrabold text-slate-900">Ringkasan Kas / Bank</h2>
              <p className="text-[11px] text-slate-400">Saldo seluruh akun</p>
            </div>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2">
            {[
              ["Rekening Utama", "Rp8.450.000"],
              ["Tabungan", "Rp12.000.000"],
              ["E-Wallet", "Rp750.000"],
              ["Cash", "Rp1.250.000"],
            ].map(([name, value]) => (
              <div key={name} className="rounded-xl bg-slate-50 p-3">
                <p className="text-[10px] text-slate-400">{name}</p>
                <p className="mt-1 text-xs font-bold text-slate-800">{value}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-5">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-blue-50 text-blue-600"><ShieldCheck size={19} /></div>
            <div>
              <h2 className="text-sm font-extrabold text-slate-900">Workspace Aman</h2>
              <p className="text-[11px] text-slate-400">Data Anda dipisahkan dengan RLS Supabase</p>
            </div>
          </div>
          <div className="mt-4 space-y-3 text-xs text-slate-500">
            {["Authentication aktif", "Row Level Security siap", "Realtime dapat diaktifkan", "Multi-user & workspace ready"].map((x) => (
              <div key={x} className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-emerald-500" />
                {x}
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}

function Placeholder({ title }) {
  return (
    <main className="mx-auto flex min-h-[calc(100vh-72px)] w-full max-w-[1500px] items-center justify-center px-4 py-8">
      <div className="card max-w-lg p-8 text-center">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-blue-50 text-blue-600">
          <FileBarChart size={26} />
        </div>
        <h1 className="mt-5 text-xl font-extrabold text-slate-900">{title}</h1>
        <p className="mt-2 text-sm leading-6 text-slate-500">
          Modul ini akan menggunakan Design System WSaku Pro yang sama dan terhubung ke Supabase.
        </p>
      </div>
    </main>
  );
}

function AuthScreen({ onAuthenticated }) {
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [workspaceName, setWorkspaceName] = useState("Keuangan Pribadi");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const submit = async (event) => {
    event.preventDefault();
    if (!supabase) {
      setError("Supabase belum dikonfigurasi. Isi VITE_SUPABASE_URL dan VITE_SUPABASE_PUBLISHABLE_KEY.");
      return;
    }
    setLoading(true); setError(""); setMessage("");
    try {
      if (mode === "register") {
        const { data, error: signUpError } = await supabase.auth.signUp({
          email: email.trim(), password,
          options: { data: { full_name: fullName.trim(), workspace_name: workspaceName.trim() || "Keuangan Pribadi" } },
        });
        if (signUpError) throw signUpError;
        if (!data.session) {
          setMessage("Akun berhasil dibuat. Silakan cek email untuk konfirmasi, lalu login.");
          setMode("login");
        } else onAuthenticated(data.session.user);
      } else {
        const { data, error: signInError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (signInError) throw signInError;
        onAuthenticated(data.user);
      }
    } catch (err) { setError(err.message || "Terjadi kesalahan."); }
    finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-8 text-slate-900 sm:px-6">
      <div className="mx-auto grid min-h-[calc(100vh-4rem)] max-w-6xl overflow-hidden rounded-[28px] bg-white shadow-2xl lg:grid-cols-[1.05fr_.95fr]">
        <div className="hidden bg-slate-950 p-10 text-white lg:flex lg:flex-col lg:justify-between">
          <Logo />
          <div className="max-w-md">
            <p className="text-sm font-bold uppercase tracking-[.2em] text-blue-400">WSaku Pro</p>
            <h1 className="mt-4 text-4xl font-black leading-tight">Keuangan lebih rapi. Keputusan lebih jelas.</h1>
            <p className="mt-5 text-sm leading-7 text-slate-300">Kelola kas, pemasukan, pengeluaran, transfer, dan laporan dalam satu workspace yang aman.</p>
            <div className="mt-8 grid grid-cols-3 gap-3 text-xs">
              {[[ShieldCheck,"RLS"],[WalletCards,"Workspace"],[ArrowLeftRight,"Transaksi"]].map(([Icon,label]) => <div key={label} className="rounded-2xl border border-white/10 bg-white/5 p-4"><Icon size={18} className="text-blue-400"/><div className="mt-3 font-bold">{label}</div></div>)}
            </div>
          </div>
          <p className="text-xs text-slate-500">© {new Date().getFullYear()} WSaku Pro</p>
        </div>
        <div className="flex items-center p-6 sm:p-10">
          <div className="mx-auto w-full max-w-md">
            <div className="lg:hidden"><Logo /></div>
            <div className="mt-8 lg:mt-0"><p className="text-xs font-bold uppercase tracking-wider text-blue-600">{mode === "login" ? "Selamat datang kembali" : "Mulai sekarang"}</p><h2 className="mt-2 text-3xl font-black tracking-tight">{mode === "login" ? "Masuk ke WSaku Pro" : "Buat akun WSaku Pro"}</h2><p className="mt-2 text-sm text-slate-500">{mode === "login" ? "Gunakan akun Anda untuk melanjutkan." : "Akun pertama akan menjadi admin workspace."}</p></div>
            <form onSubmit={submit} className="mt-8 space-y-4">
              {mode === "register" && <><label className="block text-sm font-semibold">Nama lengkap<input value={fullName} onChange={e=>setFullName(e.target.value)} required className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10" placeholder="Jajang Suryana" /></label><label className="block text-sm font-semibold">Nama workspace<input value={workspaceName} onChange={e=>setWorkspaceName(e.target.value)} className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10" /></label></>}
              <label className="block text-sm font-semibold">Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10" placeholder="nama@email.com" /></label>
              <label className="block text-sm font-semibold">Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required minLength={6} className="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10" placeholder="Minimal 6 karakter" /></label>
              {error && <div className="rounded-xl bg-red-50 px-4 py-3 text-sm font-medium text-red-700">{error}</div>}
              {message && <div className="rounded-xl bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-700">{message}</div>}
              <button disabled={loading} className="w-full rounded-xl bg-blue-600 px-4 py-3.5 text-sm font-bold text-white shadow-lg shadow-blue-600/20 transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60">{loading ? "Memproses..." : mode === "login" ? "Masuk" : "Daftar akun"}</button>
            </form>
            <button onClick={()=>{setMode(mode === "login" ? "register" : "login");setError("");setMessage("");}} className="mt-5 w-full text-sm font-semibold text-slate-500 hover:text-blue-600">{mode === "login" ? "Belum punya akun? Daftar sekarang" : "Sudah punya akun? Masuk"}</button>
          </div>
        </div>
      </div>
    </div>
  );
}

async function ensureWorkspace(user) {
  if (!supabase || !user) return null;
  const { data: memberships, error } = await supabase
    .from("workspace_members")
    .select("workspace_id, role, workspaces(id, name)")
    .eq("user_id", user.id)
    .limit(1);
  if (error) throw error;
  if (memberships?.length) return memberships[0];
  const { data: workspaceId, error: bootstrapError } = await supabase.rpc("bootstrap_workspace", {
    p_name: user.user_metadata?.workspace_name || "Keuangan Pribadi",
  });
  if (bootstrapError) throw bootstrapError;
  return { workspace_id: workspaceId, role: "admin" };
}

export default function App() {
  const [session, setSession] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState("");
  const [active, setActive] = useState("Dashboard");
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [dark, setDark] = useState(false);

  useEffect(() => {
    if (!supabase) { setAuthLoading(false); return undefined; }
    let mounted = true;
    supabase.auth.getSession().then(({ data }) => { if (mounted) { setSession(data.session); setAuthLoading(false); } });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => { if (mounted) setSession(nextSession); });
    return () => { mounted = false; listener.subscription.unsubscribe(); };
  }, []);

  useEffect(() => {
    if (!session?.user || !supabase) return;
    ensureWorkspace(session.user).catch((err) => setAuthError(err.message || "Workspace gagal disiapkan."));
  }, [session?.user?.id]);

  if (authLoading) return <div className="grid min-h-screen place-items-center bg-slate-950 text-sm font-semibold text-white">Memuat WSaku Pro...</div>;
  if (!session) return <AuthScreen onAuthenticated={(user) => setSession({ user })} />;

  const signOut = async () => { await supabase?.auth.signOut(); setSession(null); };
  const userName = session.user.user_metadata?.full_name || session.user.email?.split("@")[0] || "Pengguna";

  return (
    <div className={dark ? "dark" : ""}>
      <div className={`app-bg min-h-screen ${dark ? "bg-slate-950 text-white" : ""}`}>
        {authError && <div className="fixed right-4 top-4 z-[80] max-w-sm rounded-xl bg-red-600 px-4 py-3 text-xs font-semibold text-white shadow-xl">{authError}</div>}
        <Sidebar collapsed={collapsed} setCollapsed={setCollapsed} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} active={active} setActive={setActive} />
        <div className={`transition-all duration-200 ${collapsed ? "lg:pl-[82px]" : "lg:pl-[260px]"}`}>
          <Header setMobileOpen={setMobileOpen} collapsed={collapsed} setCollapsed={setCollapsed} dark={dark} setDark={setDark} />
          <div className="flex items-center justify-end gap-3 border-b border-slate-200/70 bg-white/70 px-4 py-2 text-xs backdrop-blur lg:px-6"><span className="text-slate-400">Masuk sebagai</span><span className="font-bold text-slate-700">{userName}</span><button onClick={signOut} className="rounded-lg px-2.5 py-1.5 font-bold text-red-600 hover:bg-red-50">Keluar</button></div>
          {active === "Dashboard" ? <Dashboard setActive={setActive} /> : <Placeholder title={active} />}
        </div>
        <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-slate-200 bg-white/95 px-2 py-2 backdrop-blur-xl lg:hidden"><div className="mx-auto grid max-w-md grid-cols-4 gap-1">{[["Dashboard",Home],["Transaksi",ArrowLeftRight],["Laporan",FileBarChart],["Pengguna",UserRound]].map(([label,Icon])=><button key={label} onClick={()=>setActive(label)} className={`flex flex-col items-center gap-1 rounded-xl py-2 text-[10px] font-bold ${active===label?"bg-blue-50 text-blue-600":"text-slate-400"}`}><Icon size={19}/>{label}</button>)}</div></nav>
      </div>
    </div>
  );
}
