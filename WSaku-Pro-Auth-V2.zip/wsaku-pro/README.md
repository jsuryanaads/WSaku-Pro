# WSaku Pro

Aplikasi manajemen keuangan multi-user berbasis React + Vite + Supabase.

## Stack
- React + Vite
- Tailwind CSS
- Lucide React
- Recharts
- Supabase Auth + PostgreSQL + RLS

## Auth & Workspace
Alur awal:
1. Register email/password.
2. Supabase Auth membuat user.
3. Trigger membuat `profiles`.
4. `bootstrap_workspace()` membuat workspace pertama dan menjadikan pemilik sebagai admin.
5. Login berikutnya langsung masuk ke dashboard.

## Environment
Buat `.env` dari `.env.example`:

```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_PUBLISHABLE_KEY=your_supabase_publishable_key
```

Jangan pernah memasukkan service role/secret key ke frontend.

## Database
`supabase_schema.sql` adalah schema untuk **project Supabase khusus WSaku Pro**. Jangan jalankan ke project Wdompet yang sudah ada tanpa migrasi yang direncanakan.

## Development
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```
